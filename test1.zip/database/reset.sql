PRAGMA foreign_keys = ON;
DELETE FROM peers;
DELETE FROM files;
DELETE FROM files_peers;